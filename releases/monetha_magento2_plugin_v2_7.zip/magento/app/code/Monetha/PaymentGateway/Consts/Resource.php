<?php

namespace Monetha\PaymentGateway\Consts;

class Resource
{
    const ORDER = 'order';
}
